# Task 1: Create a Lambda Function to Add Two Numbers
print("Task 1")
add = lambda a, b: a + b

print(add(10, 20))
print(add(15, 25))
print(add(50, 30))

# Task 2: Calculate Squares Using map()
print("\nTask 2")
numbers = [2, 4, 6, 8, 10]

squares = list(map(lambda x: x * x, numbers))

print("Original List:", numbers)
print("Squared List:", squares)


# Task 3: Filter Even Numbers Using filter()
print("\nTask 3")
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

even_numbers = list(filter(lambda x: x % 2 == 0, numbers))

print("Even Numbers:", even_numbers)


# Task 4: Calculate the Sum Using reduce()
print("\nTask 4")
from functools import reduce

numbers = [10, 20, 30, 40, 50]

total = reduce(lambda a, b: a + b, numbers)

print("Sum:", total)


# Task 5: Convert Names to Uppercase Using map()
print("\nTask 5")
names = ["bhavika", "rahul", "priya", "amit", "karan"]

uppercase_names = list(map(lambda name: name.upper(), names))

print("Original Names:", names)
print("Uppercase Names:", uppercase_names)


# Task 6: Filter Words by Length
print("\nTask 6")
words = ["apple", "banana", "cat", "orange", "computer", "dog"]

long_words = list(filter(lambda word: len(word) > 5, words))

print("Words with More Than 5 Characters:", long_words)


# Task 7: Calculate the Product of All Numbers
print("\nTask 7")
numbers = [2, 3, 4, 5]

product = reduce(lambda a, b: a * b, numbers)

print("Product:", product)


# Task 8: Find Numbers Greater Than a Given Value
print("\nTask 8")
numbers = [5, 10, 15, 20, 25, 30]

threshold = 10

greater_numbers = list(filter(lambda x: x > threshold, numbers))

print("Threshold:", threshold)
print("Greater Numbers:", greater_numbers)


# Task 9: Combine filter() and map()
print("\nTask 9")
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

even_numbers = list(filter(lambda x: x % 2 == 0, numbers))

squares = list(map(lambda x: x * x, even_numbers))

print("Even Numbers:", even_numbers)
print("Squared Even Numbers:", squares)


# Task 10: Process Employee Salaries Using Functional Programming
print("\nTask 10")
from functools import reduce

salaries = [25000, 40000, 35000, 60000, 50000]

selected_salaries = list(filter(lambda salary: salary >= 35000, salaries))

updated_salaries = list(map(lambda salary: salary * 1.10, selected_salaries))

total = reduce(lambda a, b: a + b, updated_salaries)

print("Original Salaries:", salaries)
print("Selected Salaries:", selected_salaries)
print("Updated Salaries:", [round(salary, 2) for salary in updated_salaries])
print("Total Updated Salaries:", round(total, 2))