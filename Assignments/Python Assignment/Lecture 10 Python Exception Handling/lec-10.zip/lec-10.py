# Task 1: Handle Division by Zero
print("Task 1")
try:
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))

    result = num1 / num2
    print("Division Result:", result)

except ZeroDivisionError:
    print("Error: Cannot divide by zero.")


# Task 2: Handle Invalid Integer Input
print("\nTask 2")
try:
    number = int(input("Enter an integer: "))
    print("Entered Number:", number)

except ValueError:
    print("Error: Please enter a valid integer.")


# Task 3: Handle Multiple Exceptions
print("\nTask 3")
try:
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))

    result = num1 / num2
    print("Division Result:", result)

except ValueError:
    print("Error: Please enter valid integers.")

except ZeroDivisionError:
    print("Error: Cannot divide by zero.")


# Task 4: Use the else Block
print("\nTask 4")
try:
    number = int(input("Enter a number: "))

except ValueError:
    print("Error: Please enter a valid integer.")

else:
    print("Square:", number * number)


# Task 5: Use the finally Block
print("\nTask 5")
try:
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))

    result = num1 / num2
    print("Division Result:", result)

except ValueError:
    print("Error: Please enter valid integers.")

except ZeroDivisionError:
    print("Error: Cannot divide by zero.")

finally:
    print("Operation has finished.")


# Task 6: Handle File Not Found
print("\nTask 6")
try:
    filename = input("Enter filename: ")

    with open(filename, "r") as file:
        content = file.read()
        print("File Contents:")
        print(content)

except FileNotFoundError:
    print("Error: File not found.")


# Task 7: Raise a ValueError for Invalid Age
print("\nTask 7")
def validate_age(age):
    if age < 0:
        raise ValueError("Age cannot be negative.")

    return "Age is valid."


try:
    age = int(input("Enter your age: "))
    print(validate_age(age))

except ValueError as error:
    print("Error:", error)


# Task 8: Custom Exception for Insufficient Balance
print("\nTask 8")
class InsufficientBalanceError(Exception):
    pass


balance = 5000

try:
    amount = int(input("Enter withdrawal amount: "))

    if amount <= 0:
        print("Error: Withdrawal amount must be positive.")

    elif amount > balance:
        raise InsufficientBalanceError("Insufficient account balance.")

    else:
        balance = balance - amount
        print("Withdrawal Successful.")
        print("Remaining Balance:", balance)

except InsufficientBalanceError as error:
    print("Error:", error)

except ValueError:
    print("Error: Please enter a valid amount.")


# Task 9: Re-raise an Exception
print("\nTask 9")
def convert_to_integer(value):
    try:
        return int(value)

    except ValueError:
        print("Logging: Integer conversion failed.")
        raise


try:
    value = input("Enter a value: ")
    number = convert_to_integer(value)
    print("Converted Number:", number)

except ValueError:
    print("Error: Could not convert value into an integer.")


# Task 10: User Registration Validator with Custom Exceptions
print("\nTask 10")
class InvalidUsernameError(Exception):
    pass


class InvalidAgeError(Exception):
    pass


class InvalidEmailError(Exception):
    pass


def register_user(username, age, email):

    if username.strip() == "":
        raise InvalidUsernameError("Username cannot be empty.")

    if age < 18:
        raise InvalidAgeError("Age must be 18 or above.")

    if "@" not in email:
        raise InvalidEmailError("Email must contain @.")

    return "Registration Successful."


try:
    print(register_user("Bhavika", 20, "bhavika@gmail.com"))

except InvalidUsernameError as error:
    print("Error:", error)

except InvalidAgeError as error:
    print("Error:", error)

except InvalidEmailError as error:
    print("Error:", error)


try:
    print(register_user("", 20, "user@gmail.com"))

except InvalidUsernameError as error:
    print("Error:", error)

except InvalidAgeError as error:
    print("Error:", error)

except InvalidEmailError as error:
    print("Error:", error)


try:
    print(register_user("Rahul", 16, "rahul@gmail.com"))

except InvalidUsernameError as error:
    print("Error:", error)

except InvalidAgeError as error:
    print("Error:", error)

except InvalidEmailError as error:
    print("Error:", error)