def to_uppercase(text: str) -> str:
    return text.upper()


def to_lowercase(text: str) -> str:
    return text.lower()


def count_words(text: str) -> int:
    return len(text.split())


def reverse_string(text: str) -> str:
    return text[::-1]