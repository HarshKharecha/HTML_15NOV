# Task 1: Mathematical Operations Using the math Module
print("Task 1")
import math

def main():
    raw_input = input("Enter a number: ").strip()

    try:
        num = float(raw_input)
        if math.isnan(num) or math.isinf(num):
            print("Error: Please enter a finite numeric value.")
            return
    except ValueError:
        print("Error: Invalid input. Please enter a valid number.")
        return

    print(f"\nResults for {num}:")

    # Square root (only defined for non-negative real numbers)
    if num < 0:
        print("Square root: Undefined for negative numbers.")
    else:
        print(f"Square root: {math.sqrt(num):.4f}")

    # Ceiling and floor
    print(f"Ceiling: {math.ceil(num)}")
    print(f"Floor: {math.floor(num)}")

    # Factorial (defined for non-negative integers)
    if num >= 0 and num.is_integer():
        int_num = int(num)
        print(f"Factorial ({int_num}!): {math.factorial(int_num)}")
    else:
        print("Factorial: Only applicable to non-negative integers.")


if __name__ == "__main__":
    main()

# Task 2: Random Number Generator & Dice Simulator
print("\nTask 2")
import random

def main():
    # 1. Random integer between 1 and 100
    random_num = random.randint(1, 100)
    print(f"Random integer (1-100): {random_num}")

    # 2. Simulate six-sided dice rolls
    while True:
        rolls_input = input("\nHow many times would you like to roll the six-sided die? ").strip()
        try:
            num_rolls = int(rolls_input)
            if num_rolls <= 0:
                print("Please enter a positive integer greater than 0.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a whole number (e.g., 3).")

    print(f"\nRolling a 6-sided die {num_rolls} time(s):")
    results = []
    for i in range(1, num_rolls + 1):
        roll = random.randint(1, 6)
        results.append(roll)
        print(f"  Roll {i}: {roll}")

    print(f"All results: {results}")


if __name__ == "__main__":
    main()

# Task 3: Date and Time Management
print("\nTask 3")
from datetime import datetime, timedelta

def main():
    now = datetime.now()

    print("Current Date & Time Details:")
    print(f"  Full timestamp : {now}")
    print(f"  Date (DD-MM-YYYY): {now.strftime('%d-%m-%Y')}")
    print(f"  Time (HH:MM:SS)  : {now.strftime('%H:%M:%S')}")

    while True:
        days_input = input("\nEnter number of days to add (can be positive or negative): ").strip()
        try:
            days = int(days_input)
            break
        except ValueError:
            print("Invalid input. Please enter a valid integer (e.g., 10 or -5).")

    future_date = now + timedelta(days=days)
    print(f"\nDate after {days} day(s): {future_date.strftime('%d-%m-%Y')} ({future_date.strftime('%A')})")


if __name__ == "__main__":
    main()

# Task 4: Create a Custom Calculator Module
print("\nTask 4")
import utilities.calculator as calculator

def main():
    try:
        a = float(input("Enter first number: ").strip())
        b = float(input("Enter second number: ").strip())
    except ValueError:
        print("Error: Please enter valid numeric values.")
        return

    op = input("Choose operation (+, -, *, /): ").strip()

    try:
        if op == "+":
            result = calculator.add(a, b)
        elif op == "-":
            result = calculator.subtract(a, b)
        elif op == "*":
            result = calculator.multiply(a, b)
        elif op == "/":
            result = calculator.divide(a, b)
        else:
            print(f"Error: Unsupported operation '{op}'.")
            return

        print(f"Result: {result}")
    except ZeroDivisionError as exc:
        print(f"Math Error: {exc}")

if __name__ == "__main__":
    main()

# Task 5: Create a Text Utility Module
print("\nTask 5")
from utilities.text_utils import count_words, reverse_string, to_lowercase, to_uppercase

def main():
    sentence = input("Enter a sentence: ")

    print("\nText Processing Results:")
    print(f"  Uppercase  : {to_uppercase(sentence)}")
    print(f"  Lowercase  : {to_lowercase(sentence)}")
    print(f"  Word Count : {count_words(sentence)}")
    print(f"  Reversed   : {reverse_string(sentence)}")


if __name__ == "__main__":
    main()

# Task 6: Create a Python Package (utilities)
print("\nTask 6")
from utilities import (
    add,
    count_words,
    divide,
    multiply,
    reverse_string,
    subtract,
    to_lowercase,
    to_uppercase,
)

def run_calculator() -> None:
    try:
        a = float(input("Enter first number: ").strip())
        b = float(input("Enter second number: ").strip())
    except ValueError:
        print("Error: Please enter valid numeric values.")
        return

    op = input("Choose operation (+, -, *, /): ").strip()

    try:
        if op == "+":
            result = add(a, b)
        elif op == "-":
            result = subtract(a, b)
        elif op == "*":
            result = multiply(a, b)
        elif op == "/":
            result = divide(a, b)
        else:
            print(f"Error: Unsupported operation '{op}'.")
            return

        print(f"Result: {result}")
    except ZeroDivisionError as exc:
        print(f"Math Error: {exc}")


def run_text_utils() -> None:
    sentence = input("\nEnter a sentence: ")

    print("\nText Processing Results:")
    print(f"  Uppercase  : {to_uppercase(sentence)}")
    print(f"  Lowercase  : {to_lowercase(sentence)}")
    print(f"  Word Count : {count_words(sentence)}")
    print(f"  Reversed   : {reverse_string(sentence)}")


def main() -> None:
    run_calculator()
    run_text_utils()


if __name__ == "__main__":
    main()

# Task 7: Use pip to Install an External Library (requests)
print("\nTask 7")
import requests

def fetch_url(url: str, timeout: float = 5.0) -> None:
    try:
        response = requests.get(url, timeout=timeout)
        print(f"URL: {url}")
        print(f"HTTP Status Code: {response.status_code}")
        response.raise_for_status()
        print("Request succeeded!")
    except requests.exceptions.Timeout:
        print(f"Error: Request to {url} timed out after {timeout} seconds.")
    except requests.exceptions.ConnectionError:
        print(f"Error: Failed to connect to {url}. Check your network connection.")
    except requests.exceptions.RequestException as exc:
        print(f"HTTP / Request error occurred: {exc}")


if __name__ == "__main__":
    fetch_url("https://example.com", timeout=5.0)

# Task 8: Create and Manage a Virtual Environment
print("\nTask 8: Check virtual_env_project folder")
# Windows (PowerShell / Command Prompt) Commands
# {"
# mkdir virtual_env_project
# cd virtual_env_project

# python -m venv .venv
# .venv\Scripts\Activate.ps1

# pip install requests
# pip list

# python -c "import requests; print('requests version:', requests.__version__)"

# deactivate
# "}

# Windows PowerShell:
# {"
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> mkdir virtual_env_project


#     Directory: D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11
#     Python Modules & Packages


# Mode                 LastWriteTime         Length Name
# ----                 -------------         ------ ----
# d-----        11/20/2026  11:02 PM                virtual_env_project


# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> cd virtual_env_project
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages\virtual_env_project> python -m venv .venv
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages\virtual_env_project> .venv\Scripts\Activate.ps1
# (.venv) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages\virtual_env_project> pip install requests
# Collecting requests
#   Using cached requests-2.34.2-py3-none-any.whl.metadata (4.8 kB)
# Collecting charset_normalizer<4,>=2 (from requests)
#   Using cached charset_normalizer-3.5.2-cp311-cp311-win_amd64.whl.metadata (47 kB)
# Collecting idna<4,>=2.5 (from requests)
#   Using cached idna-3.20-py3-none-any.whl.metadata (7.2 kB)
# Collecting urllib3<3,>=1.26 (from requests)
#   Using cached urllib3-2.8.0-py3-none-any.whl.metadata (7.4 kB)
# Collecting certifi>=2023.5.7 (from requests)
#   Using cached certifi-2026.10.23-py3-none-any.whl.metadata (2.5 kB)
# Using cached requests-2.34.2-py3-none-any.whl (73 kB)
# Using cached certifi-2026.10.23-py3-none-any.whl (135 kB)
# Using cached charset_normalizer-3.5.2-cp311-cp311-win_amd64.whl (214 kB)
# Using cached idna-3.20-py3-none-any.whl (69 kB)
# Using cached urllib3-2.8.0-py3-none-any.whl (135 kB)
# Installing collected packages: urllib3, idna, charset_normalizer, certifi, requests
# Successfully installed certifi-2026.10.23 charset_normalizer-3.5.2 idna-3.20 requests-2.34.2 urllib3-2.8.0

# [notice] A new release of pip is available: 24.0 -> 26.3
# [notice] To update, run: python.exe -m pip install --upgrade pip
# (.venv) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages\virtual_env_project> pip list
# Package            Version
# ------------------ ----------
# certifi            2026.10.23
# charset-normalizer 3.5.2
# idna               3.20
# pip                24.0
# requests           2.34.2
# setuptools         65.5.0
# urllib3            2.8.0

# [notice] A new release of pip is available: 24.0 -> 26.3
# [notice] To update, run: python.exe -m pip install --upgrade pip
# (.venv) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages\virtual_env_project> python -c "import requests; print('requests version:', requests.__version__)"
# requests version: 2.34.2
# (.venv) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages\virtual_env_project> deactivate
# "}

# Task 9: Manage Dependencies with requirements.txt
print("\nTask 9: Check .venv1 and .venv2 folder")
# Windows (PowerShell / Command Prompt) Commands
# {"
# python -m venv .venv1
# .venv1\Scripts\Activate.ps1

# pip install requests python-dotenv
# pip freeze > requirements.txt
# Get-Content requirements.txt

# deactivate

# python -m venv .venv2
# .venv2\Scripts\Activate.ps1
# pip install -r requirements.txt

# python -c "import requests, dotenv; print('Verified:', requests.__version__, dotenv.__name__)"

# deactivate
# "}

# Windows PowerShell:
# {"
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> python -m venv .venv1
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> .venv1\Scripts\Activate.ps1
# (.venv1) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> pip install requests python-dotenv
# Collecting requests
#   Using cached requests-2.34.2-py3-none-any.whl.metadata (4.8 kB)
# Collecting python-dotenv
#   Downloading python_dotenv-1.2.4-py3-none-any.whl.metadata (29 kB)
# Collecting charset_normalizer<4,>=2 (from requests)
#   Using cached charset_normalizer-3.5.2-cp311-cp311-win_amd64.whl.metadata (47 kB)
# Collecting idna<4,>=2.5 (from requests)
#   Using cached idna-3.20-py3-none-any.whl.metadata (7.2 kB)
# Collecting urllib3<3,>=1.26 (from requests)
#   Using cached urllib3-2.8.0-py3-none-any.whl.metadata (7.4 kB)
# Collecting certifi>=2023.5.7 (from requests)
#   Using cached certifi-2026.10.23-py3-none-any.whl.metadata (2.5 kB)
# Using cached requests-2.34.2-py3-none-any.whl (73 kB)
# Downloading python_dotenv-1.2.4-py3-none-any.whl (23 kB)
# Using cached certifi-2026.10.23-py3-none-any.whl (135 kB)
# Using cached charset_normalizer-3.5.2-cp311-cp311-win_amd64.whl (214 kB)
# Using cached idna-3.20-py3-none-any.whl (69 kB)
# Using cached urllib3-2.8.0-py3-none-any.whl (135 kB)
# Installing collected packages: urllib3, python-dotenv, idna, charset_normalizer, certifi, requests
# Successfully installed certifi-2026.10.23 charset_normalizer-3.5.2 idna-3.20 python-dotenv-1.2.4 requests-2.34.2 urllib3-2.8.0

# [notice] A new release of pip is available: 24.0 -> 26.3
# [notice] To update, run: python.exe -m pip install --upgrade pip
# (.venv1) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> pip freeze > requirements.txt
# (.venv1) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> Get-Content requirements.txt
# certifi==2026.10.23
# charset-normalizer==3.5.2
# idna==3.20
# python-dotenv==1.2.4
# requests==2.34.2
# urllib3==2.8.0
# (.venv1) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> deactivate
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> python -m venv .venv2
# PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> .venv2\Scripts\Activate.ps1
# (.venv2) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> pip install -r requirements.txt
# Collecting certifi==2026.10.23 (from -r requirements.txt (line 1))
#   Using cached certifi-2026.10.23-py3-none-any.whl.metadata (2.5 kB)
# Collecting charset-normalizer==3.5.2 (from -r requirements.txt (line 2))
#   Using cached charset_normalizer-3.5.2-cp311-cp311-win_amd64.whl.metadata (47 kB)
# Collecting idna==3.20 (from -r requirements.txt (line 3))
#   Using cached idna-3.20-py3-none-any.whl.metadata (7.2 kB)
# Collecting python-dotenv==1.2.4 (from -r requirements.txt (line 4))
#   Using cached python_dotenv-1.2.4-py3-none-any.whl.metadata (29 kB)
# Collecting requests==2.34.2 (from -r requirements.txt (line 5))
#   Using cached requests-2.34.2-py3-none-any.whl.metadata (4.8 kB)
# Collecting urllib3==2.8.0 (from -r requirements.txt (line 6))
#   Using cached urllib3-2.8.0-py3-none-any.whl.metadata (7.4 kB)
# Using cached certifi-2026.10.23-py3-none-any.whl (135 kB)
# Using cached charset_normalizer-3.5.2-cp311-cp311-win_amd64.whl (214 kB)
# Using cached idna-3.20-py3-none-any.whl (69 kB)
# Using cached python_dotenv-1.2.4-py3-none-any.whl (23 kB)
# Using cached requests-2.34.2-py3-none-any.whl (73 kB)
# Using cached urllib3-2.8.0-py3-none-any.whl (135 kB)
# Installing collected packages: urllib3, python-dotenv, idna, charset-normalizer, certifi, requests
# Successfully installed certifi-2026.10.23 charset-normalizer-3.5.2 idna-3.20 python-dotenv-1.2.4 requests-2.34.2 urllib3-2.8.0

# [notice] A new release of pip is available: 24.0 -> 26.3
# [notice] To update, run: python.exe -m pip install --upgrade pip
# (.venv2) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> python -c "import requests, dotenv; print('Verified:', requests.__version__, dotenv.__name__)"
# Verified: 2.34.2 dotenv
# (.venv2) PS D:\om\Desktop\Editing\Full Stack Programming\HK\HTML_15NOV\Assignments\Python Assignment\Lecture 11 Python Modules & Packages> deactivate
# "}

# Task 10: Build a Modular User Management Application
print("\nTask 10: Check user_management_app folder")

print("\nI Try to attempted My Task 7 to 10.")