from .date_utils import get_registration_timestamp
from .validators import validate_email, validate_username


def add_user(users: list[dict], username: str, email: str) -> tuple[bool, str]:
    """Validate inputs and add a new user record if valid."""
    valid_user, user_err = validate_username(username)
    if not valid_user:
        return False, user_err

    valid_email, email_err = validate_email(email)
    if not valid_email:
        return False, email_err

    normalized_username = username.strip()
    normalized_email = email.strip().lower()

    if any(u["username"].lower() == normalized_username.lower() for u in users):
        return False, f"Username '{normalized_username}' is already registered."

    record = {
        "username": normalized_username,
        "email": normalized_email,
        "registered_at": get_registration_timestamp(),
    }
    users.append(record)
    return True, f"User '{normalized_username}' registered successfully."


def display_users(users: list[dict]) -> None:
    """Display all registered users and their registration timestamps."""
    if not users:
        print("\nNo users registered yet.")
        return

    print("\n--- Registered Users ---")
    for idx, user in enumerate(users, start=1):
        print(
            f"{idx}. Username: {user['username']} | Email: {user['email']} | Registered: {user['registered_at']}"
        )