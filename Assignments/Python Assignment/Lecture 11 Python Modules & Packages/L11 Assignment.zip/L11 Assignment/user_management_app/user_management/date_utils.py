from datetime import datetime


def get_registration_timestamp() -> str:
    """Return the current timestamp formatted for user registration."""
    return datetime.now().strftime("%d-%m-%Y %H:%M:%S")