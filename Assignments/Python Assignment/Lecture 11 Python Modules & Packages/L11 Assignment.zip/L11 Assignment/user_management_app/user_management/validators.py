import re


def validate_username(username: str) -> tuple[bool, str]:
    """Username must be 3-20 chars, alphanumeric or underscores, starting with a letter."""
    cleaned = username.strip()
    if not re.match(r"^[A-Za-z][A-Za-z0-9_]{2,19}$", cleaned):
        return (
            False,
            "Invalid username: must be 3-20 characters, start with a letter, and contain only letters, numbers, or underscores.",
        )
    return True, ""


def validate_email(email: str) -> tuple[bool, str]:
    """Basic email format validation."""
    cleaned = email.strip()
    if not re.match(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$", cleaned):
        return False, "Invalid email address format (e.g., name@example.com)."
    return True, ""