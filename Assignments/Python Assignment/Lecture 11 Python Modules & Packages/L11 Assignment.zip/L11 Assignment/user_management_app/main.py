from dotenv import load_dotenv
from user_management import add_user, display_users


def main():
    load_dotenv()
    users: list[dict] = []

    print("=== User Management System ===")
    while True:
        print("\nOptions: [1] Register User  [2] List Users  [3] Exit")
        choice = input("Select an option: ").strip()

        if choice == "1":
            username = input("Enter username: ")
            email = input("Enter email: ")
            ok, message = add_user(users, username, email)
            print(message)
        elif choice == "2":
            display_users(users)
        elif choice == "3":
            print("Exiting User Management System. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")


if __name__ == "__main__":
    main()