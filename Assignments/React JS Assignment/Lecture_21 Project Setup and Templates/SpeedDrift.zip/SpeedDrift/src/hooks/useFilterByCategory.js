import { useMemo } from 'react';

function useFilterByCategory(products, keywords) {
  const filteredProducts = useMemo(() => {
    if (!products) return [];
    if (!keywords || (Array.isArray(keywords) && keywords.length === 0)) return products;

    // Ensure keywords is always an array for easier checking
    const keywordList = Array.isArray(keywords) ? keywords : [keywords];

    return products.filter(product => {
      const category = product.category ? product.category.toLowerCase() : '';
      const name = product.name ? product.name.toLowerCase() : '';

      // Check if product matches ANY of the keywords in the array
      return keywordList.some(kw => {
        const target = kw.toLowerCase();
        return category.includes(target) || name.includes(target);
      });
    });
  }, [products, keywords]);

  return filteredProducts;
}

export default useFilterByCategory;