import { useMemo } from 'react';

function useSearchProducts(products, query) {
  const filteredProducts = useMemo(() => {
    if (!products || products.length === 0) return [];
    
    // Fix: Ensure query is a string and handle empty/whitespace-only input properly
    if (typeof query !== 'string' || query.trim() === '') return []; 

    const searchQuery = query.toLowerCase().trim();

    return products.filter(product => {
      const name = product.name ? product.name.toLowerCase() : '';
      const category = product.category ? product.category.toLowerCase() : '';
      const brand = product.brand ? product.brand.toLowerCase() : '';
      const price = product.price ? product.price.toString().toLowerCase() : '';

      return (
        name.includes(searchQuery) ||
        category.includes(searchQuery) ||
        brand.includes(searchQuery) ||
        price.includes(searchQuery)
      );
    });
  }, [products, query]);

  return filteredProducts;
}

export default useSearchProducts;