import { useState, useMemo } from 'react';

function useCategory(products = []) {
    const [selectedCategory, setSelectedCategory] = useState('All');

    // Extract unique categories dynamically from the products array
    const categories = useMemo(() => {
        return ['All', ...new Set(products.map(p => p.category))];
    }, [products]);

    // Filter products based on the currently selected category
    const filteredProducts = useMemo(() => {
        if (selectedCategory === 'All') return products;
        return products.filter(p => p.category === selectedCategory);
    }, [products, selectedCategory]);

    return {
        categories,
        selectedCategory,
        setSelectedCategory,
        filteredProducts
    };
}

export default useCategory;