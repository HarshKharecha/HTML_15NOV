import React from 'react';
import styles from '../styles/Hero.module.css';

function Hero() {
  return (
    <section className={styles.hero}>
      <h1 className={styles.heading}>Building Modern Digital Solutions</h1>
      <p className={styles.paragraph}>
        We deliver scalable architecture, high-performance web applications, and stunning user interfaces tailored to your business needs.
      </p>
    </section>
  );
}

export default Hero;