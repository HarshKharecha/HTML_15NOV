import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for routing
import useWindowSize from '../hooks/useWindowSize';

function Search({ searchQuery, setSearchQuery, filteredProducts }) {
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const { width } = useWindowSize();
    const navigate = useNavigate(); // Hook to navigate to product details

    const isMobileSidebar = width < 1280;

    const styles = {
        searchIconButton: {
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            outline: 'none',
        },
        searchIcon: {
            width: '24px',
            height: '24px',
            fill: isSearchOpen ? 'rgb(9, 51, 151)' : '#666',
            transition: 'fill 0.2s ease',
        },
        searchPopupPanel: {
            position: isMobileSidebar ? 'fixed' : 'absolute',
            top: isMobileSidebar ? 0 : '100%',
            right: 0,
            left: isMobileSidebar ? 'auto' : 0,
            bottom: isMobileSidebar ? 0 : 'auto',
            width: isMobileSidebar ? '320px' : 'auto',
            maxWidth: '100%',
            height: isMobileSidebar ? '100vh' : 'auto',
            backgroundColor: '#ffffff',
            padding: isMobileSidebar ? '24px' : '20px 24px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'flex-start',
            alignItems: isMobileSidebar ? 'stretch' : 'flex-end',
            borderBottom: isMobileSidebar ? 'none' : '1px solid #e2e8f0',
            borderLeft: isMobileSidebar ? '1px solid #e2e8f0' : 'none',
            boxShadow: isMobileSidebar
                ? '-10px 0 25px -5px rgba(0, 0, 0, 0.1)'
                : '0 10px 15px -3px rgba(0, 0, 0, 0.05)',
            transform: isSearchOpen
                ? (isMobileSidebar ? 'translateX(0)' : 'translateY(0)')
                : (isMobileSidebar ? 'translateX(100%)' : 'translateY(-100%)'),
            opacity: isSearchOpen ? 1 : 0,
            visibility: isSearchOpen ? 'visible' : 'hidden',
            transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease, visibility 0.2s',
            zIndex: 1000,
        },
        sidebarHeader: {
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px',
            width: '100%',
            gap: '12px',
        },
        closeButton: {
            background: 'none',
            border: 'none',
            fontSize: '1.25rem',
            cursor: 'pointer',
            color: '#64748b',
            padding: '4px 8px',
        },
        popupInputWrapper: {
            position: 'relative',
            width: '100%',
            maxWidth: isMobileSidebar ? '100%' : '500px',
        },
        popupInput: {
            width: '100%',
            padding: '12px 16px 12px 45px',
            fontSize: '1rem',
            borderRadius: '24px',
            border: '1px solid #cbd5e1',
            boxSizing: 'border-box',
            outline: 'none',
        },
        popupInputIcon: {
            position: 'absolute',
            left: '16px',
            top: '50%',
            transform: 'translateY(-50%)',
            width: '18px',
            height: '18px',
            fill: '#94a3b8',
            pointerEvents: 'none',
        },
        resultsContainer: {
            marginTop: '12px',
            maxHeight: '300px',
            overflowY: 'auto',
            width: '100%',
            maxWidth: '500px',
            border: '1px solid #e2e8f0',
            borderRadius: '8px',
            backgroundColor: '#fff',
        },
        resultItem: {
            padding: '10px 14px',
            borderBottom: '1px solid #f1f5f9',
            fontSize: '0.9rem',
            color: '#334155',
            cursor: 'pointer',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
        }
    };

    // Handle clicking an item from type-by-type results
    const handleSelectProduct = (product) => {
        setSearchQuery(''); // Clear search box
        setIsSearchOpen(false); // Close panel

        // Map category properly to match your dashboard route structure if needed
        const categoryPath = product.category ? product.category.toLowerCase().replace(/\s+/g, '-') : 'shop';
        navigate(`/${categoryPath}/${product.id}`);
    };

    return (
        <>
            <button
                style={styles.searchIconButton}
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                aria-label="Toggle Search Panel"
            >
                <svg style={styles.searchIcon} focusable="false" aria-hidden="true" viewBox="0 0 96 96">
                    <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)"></path>
                </svg>
            </button>

            <div style={styles.searchPopupPanel}>
                {isMobileSidebar ? (
                    <div style={styles.sidebarHeader}>
                        <div style={styles.popupInputWrapper}>
                            <svg style={styles.popupInputIcon} focusable="false" aria-hidden="true" viewBox="0 0 96 96">
                                <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)"></path>
                            </svg>
                            <input
                                style={styles.popupInput}
                                type="text"
                                placeholder="Search by name, category, brand, price..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                autoFocus={isSearchOpen}
                            />
                        </div>
                        <button
                            style={styles.closeButton}
                            onClick={() => setIsSearchOpen(false)}
                            aria-label="Close Search Sidebar"
                        >
                            ✕
                        </button>
                    </div>
                ) : (
                    <div style={styles.popupInputWrapper}>
                        <svg style={styles.popupInputIcon} focusable="false" aria-hidden="true" viewBox="0 0 96 96">
                            <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)"></path>
                        </svg>
                        <input
                            style={styles.popupInput}
                            type="text"
                            placeholder="Search by name, category, brand, price..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            autoFocus={isSearchOpen}
                        />
                    </div>
                )}

                {/* Real-time type-by-type suggestion list */}
                {searchQuery && filteredProducts && filteredProducts.length > 0 && (
                    <div style={styles.resultsContainer}>
                        {filteredProducts.map((prod) => (
                            <div
                                key={prod.id || prod.name}
                                style={styles.resultItem}
                                onClick={() => handleSelectProduct(prod)}
                            >
                                <span><strong>{prod.name}</strong> ({prod.brand})</span>
                                <span style={{ color: 'rgb(9, 51, 151)', fontWeight: '600' }}>${prod.price}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </>
    );
}

export default Search;