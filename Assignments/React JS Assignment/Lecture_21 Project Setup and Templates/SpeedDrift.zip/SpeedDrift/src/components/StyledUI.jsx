import styled from 'styled-components';

export const StyledButton = styled.button`
  background-color: ${(props) => (props.$secondary ? '#64748b' : '#2563eb')};
  color: #ffffff;
  padding: 10px 20px;
  font-size: 1rem;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.2s, background-color 0.2s;

  &:hover {
    background-color: ${(props) => (props.$secondary ? '#475569' : '#1d4ed8')};
    transform: translateY(-2px);
  }
`;

export const StyledCard = styled.div`
  background: ${(props) => props.theme.cardBg || '#ffffff'};
  color: ${(props) => props.theme.text || '#1e293b'};
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  border: 1px solid #e2e8f0;

  &:hover {
    box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.15);
    transform: translateY(-4px);
  }
`;