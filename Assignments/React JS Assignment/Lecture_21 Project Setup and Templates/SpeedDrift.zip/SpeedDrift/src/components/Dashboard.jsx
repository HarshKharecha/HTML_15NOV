import React, { useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import Layout from '../layouts/Layout'
import useFetch from '../hooks/useFetch';
import useSearchProducts from '../hooks/useSearchProducts';
import Shop from '../pages/Shop';
import ProductDetails from './ProductDetails';
import Mobiles from '../pages/Mobiles';
import TV from '../pages/TV';
import Appliances from '../pages/Appliances';
import ComputersMonitors from '../pages/ComputersMonitors';
import Wearables from '../pages/Wearables';
import Accessories from '../pages/Accessories';
import About from '../pages/About';
import Contact from '../pages/Contact';

function Dashboard() {
    const [searchQuery, setSearchQuery] = useState('');

    // API Data Fetching Hook
    const { data: apiProducts, loading: apiLoading, error: apiError } = useFetch(
        'https://mocki.io/v1/b00cc7dc-917d-41f8-98ca-4d9ee06fdfa9'
    );

    // Format products to map the first image from the 'images' array to 'image'
    const formattedProducts = apiProducts ? apiProducts.map(u => ({
        ...u,
        image: u.images ? u.images[0] : '' // Grabs the first image from the array
    })) : [];

    // Use your custom hook to filter products based on user query
    const filteredProducts = useSearchProducts(formattedProducts, searchQuery);

    return (
        <Routes>
            {/* Pass search states down to Layout/Header if Layout accepts props */}
            <Route path="/" element={<Layout searchQuery={searchQuery} setSearchQuery={setSearchQuery} filteredProducts={filteredProducts} />}>
                <Route path="shop" element={<Shop products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="shop/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path='mobiles' element={<Mobiles products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="mobiles/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path='tv-av' element={<TV products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="tv-av/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path='appliances' element={<Appliances products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="appliances/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path='computers-monitors' element={<ComputersMonitors products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="computers-monitors/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path='wearables' element={<Wearables products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="wearables/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path='accessories' element={<Accessories products={searchQuery ? filteredProducts : formattedProducts} />} />
                <Route path="accessories/:id" element={<ProductDetails products={formattedProducts} />} />
                <Route path="about" element={<About />} />
                <Route path="contact" element={<Contact />} />
            </Route>
        </Routes>
    )
}

export default Dashboard