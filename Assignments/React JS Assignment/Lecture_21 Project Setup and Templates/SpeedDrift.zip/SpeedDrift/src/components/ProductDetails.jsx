import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function ProductDetails({ products }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const styles = {
    pageWrapper: {
      fontFamily: 'system-ui, sans-serif',
      maxWidth: '1200px',
      margin: '20px auto',
      padding: '24px',
      backgroundColor: '#ffffff',
      borderRadius: '16px',
      border: '1px solid #e2e8f0',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)'
    },
    backButton: {
      marginBottom: '20px',
      padding: '8px 16px',
      backgroundColor: '#e2e8f0',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontWeight: '600'
    },
    layoutContainer: {
      display: 'flex',
      gap: '40px',
      flexWrap: 'wrap',
      alignItems: 'flex-start'
    },
    imageSection: {
      display: 'flex',
      gap: '16px',
      flex: '1 1 500px'
    },
    thumbnailColumn: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    },
    thumbnail: (isSelected) => ({
      width: '70px',
      height: '70px',
      border: isSelected ? '2px solid #2563eb' : '1px solid #cbd5e1',
      borderRadius: '8px',
      cursor: 'pointer',
      objectFit: 'contain',
      backgroundColor: '#f8fafc',
      padding: '4px',
      transition: 'all 0.2s'
    }),
    mainImageWrapper: {
      flex: 1,
      height: '450px',
      backgroundColor: '#f8fafc',
      borderRadius: '12px',
      border: '1px solid #e2e8f0',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      position: 'relative'
    },
    mainImage: {
      maxWidth: '90%',
      maxHeight: '90%',
      objectFit: 'contain',
      transition: 'transform 0.3s ease'
    },
    infoSection: {
      flex: '1 1 500px',
      display: 'flex',
      flexDirection: 'column',
      gap: '16px'
    },
    brandBadge: {
      fontSize: '0.85rem',
      color: '#64748b',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
      fontWeight: '700'
    },
    title: {
      fontSize: '1.8rem',
      fontWeight: '700',
      color: '#0f172a',
      margin: 0,
      lineHeight: '1.3'
    },
    colorInfo: {
      fontSize: '1rem',
      color: '#475569',
      margin: 0
    },
    price: {
      fontSize: '2rem',
      fontWeight: '700',
      color: '#2563eb',
      margin: 0
    },
    stockStatus: (inStock) => ({
      fontSize: '0.95rem',
      fontWeight: '700',
      color: inStock ? '#16a34a' : '#dc2626'
    }),
    sectionHeading: {
      fontSize: '1.2rem',
      fontWeight: '700',
      color: '#0f172a',
      borderBottom: '2px solid #e2e8f0',
      paddingBottom: '8px',
      marginTop: '30px',
      marginBottom: '15px'
    },
    listContainer: {
      paddingLeft: '20px',
      margin: '0',
      color: '#334155',
      lineHeight: '1.6'
    },
    specsTable: {
      width: '100%',
      borderCollapse: 'collapse',
      marginTop: '10px'
    },
    specsRow: {
      borderBottom: '1px solid #e2e8f0'
    },
    specsKey: {
      padding: '10px 12px',
      fontWeight: '600',
      color: '#475569',
      width: '40%',
      backgroundColor: '#f8fafc'
    },
    specsVal: {
      padding: '10px 12px',
      color: '#334155'
    }
  };

  // Find the product matching the route parameter 'id'
  const product = products.find((p) => p.id === id);

  const [selectedImage, setSelectedImage] = useState(product ? product.images[0] : '');
  const [isZoomed, setIsZoomed] = useState(false);

  // Update selected image if route changes
  useEffect(() => {
    if (product && product.images) {
      setSelectedImage(product.images[0]);
    }
  }, [id]);

  if (!product) {
    return (
      <div style={styles.pageWrapper}>
        <h2>Product not found!</h2>
        <button style={styles.backButton} onClick={() => navigate(-1)}>Go Back</button>
      </div>
    );
  }

  return (
    <div style={styles.pageWrapper}>
      <button style={styles.backButton} onClick={() => navigate(-1)}>← Back to Products</button>

      <div style={styles.layoutContainer}>
        {/* Left Side: Image Gallery with Vertical Thumbnails and Hover Zoom */}
        <div style={styles.imageSection}>
          <div style={styles.thumbnailColumn}>
            {product.images.map((imgUrl, index) => (
              <img
                key={index}
                src={imgUrl}
                alt={`Thumbnail ${index + 1}`}
                style={styles.thumbnail(selectedImage === imgUrl)}
                onClick={() => setSelectedImage(imgUrl)}
              />
            ))}
          </div>

          <div
            style={styles.mainImageWrapper}
            onMouseEnter={() => setIsZoomed(true)}
            onMouseLeave={() => setIsZoomed(false)}
          >
            <img
              src={selectedImage}
              alt={product.name}
              style={{
                ...styles.mainImage,
                transform: isZoomed ? 'scale(1.25)' : 'scale(1)'
              }}
            />
          </div>
        </div>

        {/* Right Side: Product Details Header, Color, Price, and Stock */}
        <div style={styles.infoSection}>
          <span style={styles.brandBadge}>{product.brand}</span>
          <h1 style={styles.title}>{product.name}</h1>
          <p style={styles.colorInfo}>Color: <b>{product.color}</b></p>
          <p style={styles.price}>{product.price}</p>
          <span style={styles.stockStatus(product.inStock)}>
            • {product.inStock ? 'In Stock & Ready to Ship' : 'Out of Stock'}
          </span>
        </div>
      </div>

      {/* Bottom Section: About This Item & Technical Specifications */}
      <div>
        <h3 style={styles.sectionHeading}>About This Item</h3>
        <ul style={styles.listContainer}>
          {product.aboutItems.map((point, index) => (
            <li key={index} style={{ marginBottom: '8px' }}>{point}</li>
          ))}
        </ul>

        <h3 style={styles.sectionHeading}>Technical Specifications</h3>
        <table style={styles.specsTable}>
          <tbody>
            {Object.entries(product.specifications).map(([key, value], index) => (
              <tr key={index} style={styles.specsRow}>
                <td style={styles.specsKey}>{key}</td>
                <td style={styles.specsVal}>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ProductDetails;