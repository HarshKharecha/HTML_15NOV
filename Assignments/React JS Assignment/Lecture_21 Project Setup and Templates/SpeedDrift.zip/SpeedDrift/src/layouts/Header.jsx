import React from 'react';
import Search from '../components/Search';

function Header({ searchQuery, setSearchQuery, filteredProducts }) {

  const styles = {
    parentContainer: {
      position: 'relative',
      zIndex: 1000,
      fontFamily: 'sans-serif',
    },
    headerWrapper: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '16px 24px',
      backgroundColor: '#ffffff',
      borderBottom: '1px solid #e2e8f0',
      fontFamily: 'sans-serif',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)',
      position: 'relative',
      zIndex: 10,
      // margin: '20px 20px 0 20px',
      // borderRadius: '12px',
    },
    logo: {
      fontSize: '1.5rem',
      fontWeight: '700',
      color: 'rgb(9, 51, 151)',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    // dateTimeContainer: {
    //   display: 'flex',
    //   alignItems: 'center',
    //   gap: '12px',
    //   fontSize: '0.95rem',
    //   color: '#64748b',
    //   fontWeight: '500',
    //   backgroundColor: '#f8fafc',
    //   padding: '8px 16px',
    //   borderRadius: '8px',
    //   border: '1px solid #e2e8f0'
    // },
    // divider: {
    //   color: '#cbd5e1',
    //   fontWeight: '300'
    // },
    // timeHighlight: {
    //   color: 'rgb(9, 51, 151)',
    //   fontWeight: '600'
    // },
  };

  // const [dateTime, setDateTime] = useState(new Date());

  // useEffect(() => {
  //   const timer = setInterval(() => setDateTime(new Date()), 1000);
  //   return () => clearInterval(timer);
  // }, []);

  // const formattedDate = dateTime.toLocaleDateString(undefined, {
  //   weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
  // });

  // const formattedTime = dateTime.toLocaleTimeString(undefined, {
  //   hour: '2-digit', minute: '2-digit', second: '2-digit',
  // });

  return (
    <>
      <div style={styles.parentContainer}>
        <div style={styles.headerWrapper}>
          <div style={styles.logo}>SPEED DRIFT</div>
          {/* <div style={styles.searchContainer}>
          <span style={styles.searchIcon}>🔍</span>
          <svg style={styles.searchIcon} focusable="false" aria-hidden="true" viewBox="0 0 96 96">
            <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)"></path>
          </svg>
          <input style={styles.searchContainerInput} type='text' placeholder='Search...' />
        </div> */}
          {/* <div style={styles.dateTimeContainer}>
          <span>📅 {formattedDate}</span>
          <span style={styles.divider}>|</span>
          <span style={styles.timeHighlight}>⏰ {formattedTime}</span>
        </div> */}
          <Search
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            filteredProducts={filteredProducts}
          />
        </div>
      </div>
    </>
  );
}

export default Header