import React from 'react'
import { Outlet } from 'react-router-dom'
import Header from './Header'
import Sidebar from './Sidebar'
import Footer from './Footer'

function Layout() {
  const styles = {
    // Main wrapper to stack Header, Content Area, and Footer vertically
    mainLayout: {
      display: 'flex',
      flexDirection: 'column',
      minHeight: '100vh',
      fontFamily: 'system-ui, sans-serif',
      backgroundColor: '#f8fafc'
    },
    // Flex container to push Sidebar to the left and Page Content to the right
    contentBody: {
      display: 'flex',
      flex: 1,
      gap: '20px',
      padding: '20px',
      boxSizing: 'border-box'
    },
    // Container that holds the active page (Shop, Mobiles, etc.) on the right
    pageContent: {
      flex: 1,
      backgroundColor: '#ffffff',
      borderRadius: '16px',
      border: '1px solid #e2e8f0',
      padding: '20px',
      overflowY: 'auto'
    }
  };

  return (
    <div style={styles.mainLayout}>
      <Header />
      <div style={styles.contentBody}>
        <Sidebar />
        <div style={styles.pageContent}>
          <Outlet />
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default Layout