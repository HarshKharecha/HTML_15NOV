import React from 'react';
import { NavLink } from 'react-router-dom';

function Sidebar() {
    const styles = {
        sidebar: {
            width: '220px',
            // height: '100vh',
            backgroundColor: '#ffffff',
            color: '#111827',
            fontFamily: 'sans-serif',
            padding: '1.5rem 1rem',
            borderRadius: '12px',
            borderRight: '1px solid #e2e8f0',
            boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)',
            boxSizing: 'border-box'
        },
        list: { listStyle: 'none', padding: 0, margin: 0 },
        item: {
            padding: '0.75rem 0',
            borderBottom: '1px solid #e5e7eb'
        },
        getLinkStyle: ({ isActive }) => ({
            color: isActive ? '#38bdf8' : '#0f172a',
            textDecoration: 'none',
            fontWeight: '600',
            borderBottom: isActive ? '2px solid #38bdf8' : '2px solid transparent',
            paddingBottom: '4px'
        })
    };

    return (
        <>
            <aside style={styles.sidebar}>
                <ul style={styles.list}>
                    <li style={styles.item}>
                        <NavLink to="/shop" style={styles.getLinkStyle}>Shop</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/mobiles" style={styles.getLinkStyle}>Mobiles</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/tv-av" style={styles.getLinkStyle}>TV&AV</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/appliances" style={styles.getLinkStyle}>Appliances</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/computers-monitors" style={styles.getLinkStyle}>Computers&Monitors</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/wearables" style={styles.getLinkStyle}>Wearables</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/accessories" style={styles.getLinkStyle}>Accessories</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/about" style={styles.getLinkStyle}>About Us</NavLink>
                    </li>
                    <li style={styles.item}>
                        <NavLink to="/contact" style={styles.getLinkStyle}>Contact Us</NavLink>
                    </li>
                </ul>
            </aside>
        </>
    );
}

export default Sidebar;