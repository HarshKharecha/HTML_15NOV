import React, { useState } from 'react';
import { StyledButton } from '../components/StyledUI';

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Form submitted successfully!');
  };

  return (
    <div style={{ padding: '40px 20px', maxWidth: '500px', margin: '0 auto' }}>
      <h2>Contact Us</h2>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '15px', marginTop: '20px' }}>
        <input 
          type="text" placeholder="Your Name" 
          value={form.name} onChange={(e) => setForm({...form, name: e.target.value})}
          style={{ padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
        />
        <input 
          type="email" placeholder="Your Email" 
          value={form.email} onChange={(e) => setForm({...form, email: e.target.value})}
          style={{ padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
        />
        <textarea 
          placeholder="Your Message" rows="4"
          value={form.message} onChange={(e) => setForm({...form, message: e.target.value})}
          style={{ padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
        />
        <StyledButton type="submit">Send Message</StyledButton>
      </form>
    </div>
  );
}

export default Contact;