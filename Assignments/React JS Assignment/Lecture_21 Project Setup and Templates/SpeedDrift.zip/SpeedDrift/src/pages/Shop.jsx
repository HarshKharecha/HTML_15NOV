import React from 'react'
import { useNavigate } from 'react-router-dom';
import useCategory from '../hooks/useCategory';

function Shop({ products }) {
  const navigate = useNavigate();

  const { categories, selectedCategory, setSelectedCategory, filteredProducts } = useCategory(products);

  const styles = {
    mainContainer: { fontFamily: 'system-ui, sans-serif', margin: '20px', padding: '24px', backgroundColor: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0' },
    container: { display: 'flex', gap: '20px', flexWrap: 'wrap', padding: '20px' },
    categoryCard: (isSelected) => ({
      backgroundColor: isSelected ? '#2563eb' : '#ffffff',
      color: isSelected ? '#ffffff' : '#1e293b',
      border: '1px solid #e2e8f0',
      borderRadius: '12px',
      padding: '10px 18px',
      fontWeight: '600',
      cursor: 'pointer',
      boxShadow: '0 2px 4px rgba(0,0,0,0.02)',
      transition: 'all 0.2s ease'
    }),
    card: { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '16px', padding: '20px', width: '220px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' },
    imageWrapper: { width: '100%', height: '160px', backgroundColor: '#f1f5f9', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: '15px' },
    image: { maxWidth: '85%', maxHeight: '85%', objectFit: 'contain' },
    title: { fontSize: '1.1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 8px 0' },
    price: { fontSize: '1.2rem', fontWeight: '700', color: '#2563eb', margin: '0 0 15px 0' },
    button: {
      backgroundColor: '#2563eb',
      color: '#ffffff',
      border: 'none',
      borderRadius: '8px',
      padding: '10px 14px',
      fontWeight: '600',
      cursor: 'pointer',
      width: '100%',
      boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      transition: 'background-color 0.2s'
    },
    stockStatus: (inStock) => ({
      fontSize: '0.95rem',
      fontWeight: '700',
      color: inStock ? '#16a34a' : '#dc2626'
    })
  };

  return (

    <>
      <div style={styles.container}>
        {categories.map((category, index) => (
          <div
            key={index}
            style={styles.categoryCard(selectedCategory === category)}
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </div>
        ))}
      </div>
      <div style={styles.container}>
        {/* {products.map(product => (
        <div key={product.id} style={styles.card}>
          <div style={styles.imageWrapper}>
            <img src={product.image} alt={product.name} style={styles.image} />
          </div>
          <div>
            <h4 style={styles.title}>{product.name}</h4>
            <span style={styles.stockStatus(product.inStock)}>• {product.inStock ? 'In Stock' : 'Out of Stock'}</span>
            <p style={styles.price}>{product.price}</p>
            <div>
              <button
                style={styles.button}
                onClick={() => navigate(`/shop/${product.id}`)}
              >
                View Product
              </button>
            </div>
          </div>
        </div>
      ))} */}

        {filteredProducts.map((product) => (
          <div
            key={product.id}
            style={styles.card}
            onClick={() => navigate(`/shop/${product.id}`)}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#2563eb';
              e.currentTarget.style.boxShadow = '0px 10px 15px -3px rgba(37, 99, 235, 0.3)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              const elements = e.currentTarget.querySelectorAll('h4, p');
              elements.forEach(el => {
                el.style.color = '#ffffff';
              });
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#ffffff';
              e.currentTarget.style.boxShadow = '0px 4px 6px -1px rgba(0,0,0,0.02)';
              e.currentTarget.style.transform = 'translateY(0px)';
              const elements = e.currentTarget.querySelectorAll('h4, p');
              elements.forEach((el, index) => {
                if (index === 0) {
                  el.style.color = '#1e293b'; // h4 title original color
                } else if (index === 1) {
                  el.style.color = '#1e293b'; // category text original color
                } else if (index === 2) {
                  el.style.color = '#2563eb'; // price original color
                }
              });
            }}
          >
            <div style={styles.imageWrapper}>
              <img src={product.image} alt={product.name} style={styles.image} />
            </div>
            <div>
              <h4 style={styles.title}>{product.name}</h4>
              <p style={styles.categoryText}>{product.category}</p>
              <span style={styles.stockStatus(product.inStock)}>• {product.inStock ? 'In Stock' : 'Out of Stock'}</span>
              <p style={styles.price}>{product.price}</p>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}

export default Shop