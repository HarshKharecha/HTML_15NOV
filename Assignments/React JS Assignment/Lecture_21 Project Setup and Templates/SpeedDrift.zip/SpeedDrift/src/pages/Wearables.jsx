import React from 'react'
import { useNavigate } from 'react-router-dom';
import useFilterByCategory from '../hooks/useFilterByCategory';

function Wearables({ products }) {
  const navigate = useNavigate();

  // Use the custom hook to filter products for "mobile" or "smartphone"
  const WearablesProducts = useFilterByCategory(products, 'Wearables');

  const styles = {
    container: { display: 'flex', gap: '20px', flexWrap: 'wrap', padding: '20px' },
    card: { backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '16px', padding: '20px', width: '220px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', cursor: 'pointer', transition: 'all 0.2s' },
    imageWrapper: { width: '100%', height: '160px', backgroundColor: '#f1f5f9', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: '15px' },
    image: { maxWidth: '85%', maxHeight: '85%', objectFit: 'contain' },
    title: { fontSize: '1.1rem', fontWeight: '600', color: '#1e293b', margin: '0 0 8px 0' },
    categoryText: { fontSize: '0.85rem', color: '#64748b', marginBottom: '8px' },
    price: { fontSize: '1.2rem', fontWeight: '700', color: '#2563eb', margin: '0 0 15px 0' },
    stockStatus: (inStock) => ({
      fontSize: '0.95rem',
      fontWeight: '700',
      color: inStock ? '#16a34a' : '#dc2626'
    }),
    noData: { padding: '20px', color: '#64748b', fontSize: '1.1rem' }
  };

  return (
    <div>
      <h2 style={{ paddingLeft: '20px', color: '#1e293b' }}>Explore Wearables</h2>

      {WearablesProducts.length === 0 ? (
        <p style={styles.noData}>No Wearables products found.</p>
      ) : (
        <div style={styles.container}>
          {WearablesProducts.map((product) => (
            <div
              key={product.id}
              style={styles.card}
              onClick={() => navigate(`/computers-monitors/${product.id}`)}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#2563eb';
                e.currentTarget.style.boxShadow = '0px 10px 15px -3px rgba(37, 99, 235, 0.3)';
                e.currentTarget.style.transform = 'translateY(-2px)';
                const elements = e.currentTarget.querySelectorAll('h4, p');
                elements.forEach(el => {
                  el.style.color = '#ffffff';
                });
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#ffffff';
                e.currentTarget.style.boxShadow = '0px 4px 6px -1px rgba(0,0,0,0.02)';
                e.currentTarget.style.transform = 'translateY(0px)';
                const elements = e.currentTarget.querySelectorAll('h4, p');
                elements.forEach((el, index) => {
                  if (index === 0) {
                    el.style.color = '#1e293b'; // h4 title original color
                  } else if (index === 1) {
                    el.style.color = '#1e293b'; // category text original color
                  } else if (index === 2) {
                    el.style.color = '#2563eb'; // price original color
                  }
                });
              }}
            >
              <div style={styles.imageWrapper}>
                <img src={product.image} alt={product.name} style={styles.image} />
              </div>
              <div>
                <h4 style={styles.title}>{product.name}</h4>
                <p style={styles.categoryText}>{product.category}</p>
                <span style={styles.stockStatus(product.inStock)}>• {product.inStock ? 'In Stock' : 'Out of Stock'}</span>
                <p style={styles.price}>{product.price}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default Wearables