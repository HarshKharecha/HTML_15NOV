import React from 'react';
import { StyledCard } from '../components/StyledUI';

function About() {
  return (
    <div style={{ padding: '40px 20px', maxWidth: '800px', margin: '0 auto' }}>
      <h2>About Our Company</h2>
      <p style={{ margin: '15px 0' }}>We are an innovative tech company focused on building cutting-edge web experiences.</p>
      
      <div style={{ display: 'grid', gap: '20px', marginTop: '20px' }}>
        <StyledCard>
          <h3>Our Mission</h3>
          <p>To empower businesses through robust software solutions and clean architecture.</p>
        </StyledCard>
        <StyledCard>
          <h3>Our Vision</h3>
          <p>To be the global leader in modern component-driven web development.</p>
        </StyledCard>
      </div>
    </div>
  );
}

export default About;