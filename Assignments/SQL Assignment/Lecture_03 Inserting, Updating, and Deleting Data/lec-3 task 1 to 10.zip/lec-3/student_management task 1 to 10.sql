-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2026 at 07:05 PM
-- Server version: 10.11.16-MariaDB
-- PHP Version: 8.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `fees` decimal(10,2) DEFAULT NULL,
  `admission_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_name`, `email`, `course`, `city`, `fees`, `admission_date`) VALUES
(1, 'Rahul Sharma', 'rahul@gmail.com', 'Data Science', 'Surat', 45000.00, '2026-01-10'),
(2, 'Priya Patel', 'priya@gmail.com', 'Web Development', 'Surat', 45000.00, '2026-01-15'),
(3, 'Amit Shah', 'amit@gmail.com', 'Digital Marketing', 'Vadodara', 28000.00, '2026-01-20'),
(4, 'Neha Desai', 'neha@gmail.com', 'Data Analytics', 'Rajkot', 32000.00, '2026-02-01'),
(6, 'Riya Joshi', 'riya@gmail.com', 'Web Development', 'Surat', 45000.00, '2026-02-10'),
(7, 'Meet Patel', 'meet@gmail.com', 'Digital Marketing', 'Rajkot', 30000.00, '2026-02-15'),
(8, 'Krisha Shah', 'krisha@gmail.com', 'Data Analytics', 'Vadodara', 42000.00, '2026-03-01'),
(9, 'Dev Mehta', 'dev@gmail.com', 'Web Development', 'Ahmedabad', 45000.00, '2026-03-05'),
(10, 'Jiya Desai', 'jiya@gmail.com', 'Data Science', 'Surat', 55000.00, '2026-03-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
