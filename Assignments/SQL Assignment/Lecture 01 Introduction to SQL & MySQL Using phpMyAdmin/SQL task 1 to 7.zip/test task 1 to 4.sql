-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2026 at 07:25 PM
-- Server version: 10.11.16-MariaDB
-- PHP Version: 8.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Student_id` int(11) NOT NULL,
  `Student_name` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Course` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Student_id`, `Student_name`, `Age`, `Gender`, `Course`, `City`) VALUES
(1, 'Harsh', 22, 'Male', 'Electronics and Communication Engineering', 'Ahmedabad'),
(2, 'Bhavika', 16, 'Female', 'Business Administration', 'Ahmedabad'),
(3, 'Chirag Mehta', 20, 'Male', 'Mechanical Engineering', 'Mumbai'),
(4, 'Divya Shah', 18, 'Female', 'Information Technology', 'Surat'),
(5, 'Esha Verma', 21, 'Female', 'Economics', 'Delhi'),
(6, 'Farhan Khan', 19, 'Male', 'Civil Engineering', 'Bangalore'),
(7, 'Gauri Joshi', 20, 'Female', 'Data Science', 'Pune'),
(8, 'Harsh Gupta', 18, 'Male', 'Electronics', 'Hyderabad'),
(9, 'Isha Kapoor', 19, 'Female', 'Architecture', 'Jaipur'),
(10, 'Jatin Kumar', 22, 'Male', 'MBA', 'Chennai'),
(11, 'Kavya Nair', 18, 'Female', 'Biotechnology', 'Kochi'),
(12, 'Lakshya Malhotra', 20, 'Male', 'Mechanical Engineering', 'Delhi'),
(13, 'Meera Sen', 19, 'Female', 'Fine Arts', 'Kolkata'),
(14, 'Nikhil Rao', 21, 'Male', 'Physics', 'Hyderabad'),
(15, 'Omprakash Yadav', 20, 'Male', 'Mathematics', 'Patna'),
(16, 'Pooja Deshmukh', 18, 'Female', 'Chemistry', 'Pune'),
(17, 'Qasim Ali', 19, 'Male', 'Computer Science', 'Lucknow'),
(18, 'Riya Thakkar', 20, 'Female', 'Commerce', 'Ahmedabad'),
(19, 'Sameer Kulkarni', 21, 'Male', 'Electrical Engineering', 'Nagpur'),
(20, 'Tanvi Bansal', 19, 'Female', 'Design', 'Chandigarh'),
(21, 'Utkarsh Sinha', 22, 'Male', 'Information Technology', 'Ranchi'),
(22, 'Vaishnavi Iyer', 18, 'Female', 'Biology', 'Chennai'),
(23, 'Waseem Akram', 20, 'Male', 'Commerce', 'Srinagar'),
(24, 'Xenia D’Souza', 19, 'Female', 'Literature', 'Goa'),
(25, 'Yashowardhan Singh', 21, 'Male', 'History', 'Jaipur'),
(26, 'Zoya Akhtar', 18, 'Female', 'Journalism', 'Mumbai'),
(27, 'Aditya Roy', 20, 'Male', 'Computer Science', 'Kolkata'),
(28, 'Bhumika Trivedi', 19, 'Female', 'Business Administration', 'Ahmedabad'),
(29, 'Chetan Bhagat', 22, 'Male', 'English', 'Delhi'),
(30, 'Deepika Padukone', 18, 'Female', 'Psychology', 'Bangalore'),
(31, 'Emraan Hashmi', 20, 'Male', 'Film Studies', 'Mumbai'),
(32, 'Falguni Pathak', 19, 'Female', 'Music', 'Vadodara'),
(33, 'Girish Karnad', 21, 'Male', 'Theatre', 'Bangalore'),
(34, 'Hema Malini', 18, 'Female', 'Dance', 'Chennai'),
(35, 'Imran Khan', 20, 'Male', 'Political Science', 'Delhi'),
(36, 'Jaya Bachchan', 19, 'Female', 'Sociology', 'Kolkata'),
(37, 'Karan Johar', 21, 'Male', 'Media Studies', 'Mumbai'),
(38, 'Lata Mangeshkar', 18, 'Female', 'Music', 'Indore'),
(39, 'Manoj Bajpayee', 22, 'Male', 'Acting', 'Bettiah'),
(40, 'Nargis Fakhri', 19, 'Female', 'Fashion', 'New York'),
(41, 'Om Puri', 20, 'Male', 'Drama', 'Ambala'),
(42, 'Preity Zinta', 18, 'Female', 'English', 'Shimla'),
(43, 'Ranbir Kapoor', 21, 'Male', 'Cinematography', 'Mumbai'),
(44, 'Smita Patil', 19, 'Female', 'Sociology', 'Pune'),
(45, 'Sunil Shetty', 22, 'Male', 'Hotel Management', 'Mangalore'),
(46, 'Tabu Hashmi', 18, 'Female', 'Economics', 'Hyderabad'),
(47, 'Uday Chopra', 20, 'Male', 'Finance', 'Mumbai'),
(48, 'Vidya Balan', 19, 'Female', 'Sociology', 'Palakkad'),
(49, 'Shah Rukh Khan', 21, 'Male', 'Economics', 'Delhi'),
(50, 'Madhuri Dixit', 18, 'Female', 'Microbiology', 'Mumbai');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
