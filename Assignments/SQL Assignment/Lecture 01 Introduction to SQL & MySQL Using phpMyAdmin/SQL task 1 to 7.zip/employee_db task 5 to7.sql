-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2026 at 07:24 PM
-- Server version: 10.11.16-MariaDB
-- PHP Version: 8.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `employee_name`, `department`, `designation`, `salary`, `city`, `email`) VALUES
(101, 'Rahul Sharma', 'IT', 'Software Developer', 35000.00, 'Ahmedabad', 'rahul@gmail.com'),
(102, 'Priya Patel', 'HR', 'HR Manager', 55000.00, 'Surat', 'priya@gmail.com'),
(103, 'Amit Shah', 'Finance', 'Accountant', 35000.00, 'Vadodara', 'amit@gmail.com'),
(104, 'Neha Desai', 'Marketing', 'Marketing Executive', 40000.00, 'Rajkot', 'neha@gmail.com'),
(105, 'Karan Mehta', 'IT', 'Web Developer', 38000.00, 'Ahmedabad', 'karan@gmail.com'),
(107, 'Arjun Parmar', 'IT', 'Python Developer', 50000.00, 'Surat', 'arjun@gmail.com'),
(108, 'Pooja Trivedi', 'HR', 'HR Executive', 30000.00, 'Vadodara', 'pooja@gmail.com'),
(109, 'Dhruv Patel', 'Finance', 'Financial Analyst', 48000.00, 'Ahmedabad', 'dhruv@gmail.com'),
(110, 'Sneha Shah', 'Marketing', 'Marketing Manager', 60000.00, 'Rajkot', 'sneha@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
