-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2026 at 07:21 PM
-- Server version: 10.11.16-MariaDB
-- PHP Version: 8.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `frameboxx_institute`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `course_fee` decimal(10,2) DEFAULT NULL,
  `course_level` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `duration`, `course_fee`, `course_level`) VALUES
(1, 'Python Programming', '6 Months', 25000.00, 'Beginner'),
(2, 'Java Development', '8 Months', 35000.00, 'Intermediate'),
(3, 'Full Stack Development', '12 Months', 50000.00, 'Advanced'),
(4, 'Web Designing', '4 Months', 18000.00, 'Beginner'),
(5, 'Database Management', '3 Months', 15000.00, 'Intermediate');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(100) DEFAULT NULL,
  `department_head` varchar(100) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `department_head`, `created_date`) VALUES
(1, 'Computer Engineering', 'Rajesh Patel', '2022-01-10'),
(2, 'Web Development', 'Pooja Shah', '2022-03-15'),
(3, 'Software Development', 'Amit Desai', '2023-02-20'),
(4, 'Database Management', 'Nisha Mehta', '2023-05-10'),
(5, 'Networking', 'Vijay Joshi', '2024-01-05');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(150) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `student_city` varchar(50) DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `student_status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_name`, `email`, `phone_number`, `student_city`, `admission_date`, `student_status`) VALUES
(1, 'Rahul Sharma', 'rahul@gmail.com', '9876543210', 'Ahmedabad', '2025-01-10', NULL),
(2, 'Priya Patel', 'priya@gmail.com', '9876543211', 'Surat', '2025-02-15', NULL),
(3, 'Amit Shah', 'amit@gmail.com', '9876543212', 'Vadodara', '2025-03-20', NULL),
(4, 'Neha Desai', 'neha@gmail.com', '9876543213', 'Rajkot', '2025-04-05', NULL),
(5, 'Karan Mehta', 'karan@gmail.com', '9876543214', 'Ahmedabad', '2025-05-12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_name`, `email`, `specialization`, `salary`) VALUES
(1, 'Rajesh Patel', 'rajesh@gmail.com', 'Python', 45000.00),
(2, 'Pooja Shah', 'pooja@gmail.com', 'Java', 50000.00),
(3, 'Amit Desai', 'amitd@gmail.com', 'Web Development', 40000.00),
(4, 'Nisha Mehta', 'nisha@gmail.com', 'Database', 42000.00),
(5, 'Vijay Joshi', 'vijay@gmail.com', 'Networking', 48000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
